import React from 'react'
import styles from '../styles/style.module.css'
const About = () => {
  return (
    <div className={styles.body}>about</div>
  )
}

export default About;